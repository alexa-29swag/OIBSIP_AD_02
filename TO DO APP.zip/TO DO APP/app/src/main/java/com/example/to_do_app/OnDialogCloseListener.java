package com.example.to_do_app;

import android.content.DialogInterface;

public interface OnDialogCloseListener {
    void onDialogClose(DialogInterface dialogInterface);

}
